<?php
if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
}
?>


<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Controle - Home</title>

        <!-- Custom fonts for this template-->
        <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="../css/sb-admin.css" rel="stylesheet">

    </head>

    <body id="page-top">

        <!--Cabeçalho-->
        <?php include('header.html'); ?>
        <div id="wrapper">

            <!-- Sidebar -->
            <?php include('sidebar.php'); ?>

            <div class="card card-body mb-3">
                <div class="card border my-2 p-1">
                    <div class="row">
                        <span class="display-4 col-sm" id="displayData">25/09/2019</span>
                        <div class="col-sm align-self-center">
                            <form class="form-inline float-right mr-2">
                                <div class="form-group mx-sm-3 mb-2">
                                    <input type="date" class="form-control" id="inputData">
                                </div>
                                <!--<button type="submit" class="btn btn-primary mb-2">Ok</button>-->
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card mb-3" style="margin-bottom: 3rem !important">
                    <div class="card-header">
                        <i class="fas fa-table"></i>
                        Tabela de Passagens</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>ID Passagem</th>
                                        <th>Pessoa</th>
                                        <th>Data e Hora</th>
                                    </tr>
                                </thead>

                                <tfoot>
                                    <tr>
                                        <th>ID Passagem</th>
                                        <th>Pessoa</th>
                                        <th>Data e Hora</th>
                                    </tr>
                                </tfoot>

                                <tbody id="bodyDataTable">

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- Sticky Footer -->
        <footer class="sticky-footer">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright © Controle de Acesso 2019</span>
                </div>
            </div>
        </footer>

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>


        <!-- Logout Modal-->
        <?php include 'logoutModal.html'; ?>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../vendor/chart.js/Chart.min.js"></script>
    <script src="../vendor/datatables/jquery.dataTables.js"></script>
    <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page
    <script src="../js/demo/datatables-demo.js"></script>
    <script src="../js/demo/chart-area-demo.js"></script>-->

    <!--Importar Script Personalizado
    <script src="../js/script.js" type="text/javascript"></script>-->

    <script>
        $(document).ready(function () {

        var hoje = new Date();
        var month = hoje.getMonth()+1;
        var output = hoje.getFullYear() + '-' +
    (month<10 ? '0' : '') + month + '-' +
    (hoje.getDate()<10 ? '0' : '') + hoje.getDate();
            $("#inputData").val(output);
            $("#displayData").text(output);           

            (function ($) {

                $.fn.mudarDados = function () {
                    var Data = $(this).val();
                    $("#displayData").text(Data);
                    //console.log(Data);

                    $.get("Passagens.ajax.php",
                            {data: Data})
                            .done(function (data) {
                                console.log(data);

                                $("#bodyDataTable").html("");

                                for (index = 0; index < data.length; ++index) {
                                    console.log(data[index]);
                                    $("#bodyDataTable").prepend(
                                            "<tr>" +
                                            "  <td scope=\"row\">" + data[index].idPassagem + "</td>" +
                                            "  <td scope=\"row\">" + data[index].nomePessoa + "</td>" +
                                            "  <td scope=\"row\">" + data[index].dataHora + "</td>" +
                                            "</tr>"
                                            );
                                }

                            }
                            );
                };
            })(jQuery);
            
            $("#inputData").mudarDados();

            $("#inputData").change(function () {
                //var dataPesquisa = $(this).val();
                //console.log(dataPesquisa);
                $(this).mudarDados();
            });

        });

    </script>
</body>

</html>
