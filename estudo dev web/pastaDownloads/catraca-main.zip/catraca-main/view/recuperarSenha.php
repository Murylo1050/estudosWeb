<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

include '../controller/AdministradorController.php';

$email = $_POST['inputEmail'];

require '../mailer/PHPMailerAutoload.php';

function geraSenha($tamanho = 8, $maiusculas = true, $numeros = true, $simbolos = false) {
    $lmin = 'abcdefghijklmnopqrstuvwxyz';
    $lmai = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $num = '1234567890';
    $simb = '!@#$%*-';
    $retorno = '';
    $caracteres = '';
    $caracteres .= $lmin;
    if ($maiusculas)
        $caracteres .= $lmai;
    if ($numeros)
        $caracteres .= $num;
    if ($simbolos)
        $caracteres .= $simb;
    $len = strlen($caracteres);
    for ($n = 1; $n <= $tamanho; $n++) {
        $rand = mt_rand(1, $len);
        $retorno .= $caracteres[$rand - 1];
    }
    return $retorno;
}

$codigo = geraSenha(6);



$mail = new PHPMailer;

$mail->isSMTP();
$mail->Host = 'smtp.googlemail.com';
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tsl';
$mail->Username = 'airfryercatracas@gmail.com';
$mail->Password = 'alecrimdourado';
$mail->Port = 587;

$mail->setFrom('airfryercatracas@gmail.com.br', 'Air Fryer');
$mail->addAddress($email);

$mail->isHTML(true);

$assunto = "Esqueceu a senha?";
$mensagem = "Digite o código a seguir para recuperar sua senha: " . $codigo;

$mail->Subject = $assunto;
$mail->Body = nl2br($mensagem);
$mail->AltBody = nl2br(strip_tags($mensagem));

if (!$mail->send()) {
    echo 'Não foi possível enviar a mensagem.<br>';
    echo 'Erro: ' . $mail->ErrorInfo;
} else {
    $_SESSION["codigo"] = $codigo;
    $_SESSION["email"] = $email;
    header('Location: /view/novaSenha.html?enviado');
}
