<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Controle - Login</title>

        <!-- Custom fonts for this template-->
        <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Custom styles for this template-->
        <link href="../css/sb-admin.css" rel="stylesheet">

    </head>

    <body class="" style="background-color: #222;">

        <div class="container">
            <div class="row" style="height:100vh;">
                <div class="col-md-4 col-md-offset-4 text-center" style="margin:auto;">
                    <div class="">
                        <h1 class="display-4 text-primary">Controle <span class="h1">Admin</span></h1>
                        <form action="../controller/ope.php" method="post" id="formLogin" name="formLogin">
                            <div class="form-group">
                                <div class="form-label-group">
                                    <input type="text" id="inputIdEmail" name="inputIdEmail" class="form-control" placeholder="Idou Email" required="required" autofocus="autofocus">
                                    <label for="inputId">Id ou Email</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-label-group">
                                    <input type="password" id="inputSenha" name="inputSenha" class="form-control" placeholder="Senha" required="required">
                                    <label for="inputSenha">Senha</label>
                                </div>
                            </div>
                            <input id="btnEnviar" type="submit" class="btn btn-primary btn-block" value="Login" style="width: 100%"/>
                        </form>
                        <div class="text-center">
                            <a class="d-block small mt-3" href="esqueciSenha.html">Esqueceu sua senha?</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bootstrap core JavaScript-->
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    </body>

</html>
