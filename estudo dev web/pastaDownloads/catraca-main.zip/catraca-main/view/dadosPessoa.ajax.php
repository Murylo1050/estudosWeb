<?php
	header( 'Cache-Control: no-cache' );
	header( 'Content-type: application/json; charset="utf-8"', true );

        // Desative esse bloco para exibir todos os erros 
        /* ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL); */
        require_once ('../model/Pessoa.php');
        require_once ('../controller/PessoaController.php'); 

        $pessoa = new PessoaController();
        
        $idPessoa =  $_REQUEST['idPessoa'];

	$pessoa = $pessoa->SelecionarPorId($idPessoa);
	
	echo( json_encode(  $pessoa ) ); ?>