<?php

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

include '../controller/AdministradorController.php';

$administradorController = new AdministradorController();

$senha = $_POST["inputSenha"];
$codigo = $_POST["inputCodigo"];

$emailReal = $_SESSION["email"];
$codigoReal = $_SESSION["codigo"];

//var_dump($codigoReal);
//var_dump($emailReal);

if ($codigo === $codigoReal) {
    $administradorController->EsqueceuSenha($emailReal, $senha);
    //Apagando todos os dados da sessão:
    session_unset();
    //Destruindo a sessão:
    session_destroy();

    //header('location: /view/login.php');

    echo'<script> window.location.href = "/view/login.php";</script>';
} else {
    //header('location: /view/novaSenha.html');
    echo'<script> window.location.href = "/view/novaSenha.html";</script>';
}
