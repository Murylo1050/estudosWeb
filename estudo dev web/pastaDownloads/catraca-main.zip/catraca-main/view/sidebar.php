<?php
if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
}
?>

<ul class="sidebar navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="home.php">
            <i class="fas fa-fw fa-home"></i>
            <span>Página Principal</span>
        </a>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link" id="btnPerfis" href="dadosPessoa.php" role="button">
            <i class="fas fa-fw fa-id-card"></i>
            <span>Perfis</span>
        </a>
    </li>
    <?php if ($_SESSION["nivel"] == 1 || $_SESSION["nivel"] == 2) {
        ?>
        <li class="nav-item dropdown">
            <a class="nav-link" id="btnCadastro" href="cadastroPessoa.php" role="button">
                <i class="fas fa-fw fa-folder-open"></i>
                <span>Cadastro de Pessoas</span>
            </a>
        </li>
    <?php } ?>
    <?php
    if ($_SESSION["nivel"] == 1) {
        ?>
        <li class="dropdown-divider mx-2" style="border-top-color: #6c757d;"></li>
        <li class="nav-item dropdown">
            <a class="nav-link" id="btnCadastroAdm" href="cadastroAdministrador.php" role="button">
                <i class="fas fa-fw fa-folder-open"></i>
                <span>Cadastro de Admin</span>
            </a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link" id="btnCadastroAdm" href="listaAdm.php" role="button">
                <i class="fas fa-fw fa-folder-open"></i>
                <span>Lista de Admin</span>
            </a>
        </li>
    <?php }
    ?>

</ul>