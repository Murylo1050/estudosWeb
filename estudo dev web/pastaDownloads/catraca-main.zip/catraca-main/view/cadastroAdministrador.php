<?php
if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
    if ($_SESSION["nivel"] != 1) {
        header('location: home.php');
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Controle - Cadastro Administrador</title>

        <!-- Custom fonts for this template-->
        <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="../css/sb-admin.css" rel="stylesheet">

    </head>

    <body id="page-top">

        <!--Cabeçalho-->
        <?php include('header.html'); ?>

        <div id="wrapper">

            <!-- Sidebar -->
            <?php include('sidebar.php'); ?>

            <div class=" card mb-3" style="width: 100%;">
                <div class="card-header"><span class="display-4">Cadastro de Admin</span></div>
                <div class="card-body">
                    <form method="post" id="formCadastro">
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md">
                                    <div class="form-label-group">
                                        <input type="text" name="inputNome" id="inputNome" class="form-control" placeholder="Nome Completo" required="required" autofocus="autofocus">
                                        <label for="inputNome">Nome Completo</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-7">
                                    <div class="form-label-group">
                                        <input type="text" name="inputEmail" id="inputEmail" class="form-control" placeholder="Email" required="required">
                                        <label for="inputEmail">Email</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <div class="form-label-group">
                                        <input type="number" name="inputNivel" min="1" max="3" value="3" id="inputNivel" class="form-control" placeholder="Nível" required="required" autofocus="autofocus">
                                        <label for="inputNivel">Nível</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md">
                                    <div class="form-label-group">
                                        <input type="password" name="inputSenha" id="inputSenha" class="form-control" placeholder="Senha" required="required">
                                        <label for="inputSenha">Senha</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center flex-column">
                            <input  type="submit" id="btnEnviar" class="btn btn-success btn-block align-self-center" style="width: 50%;" href="" value="Cadastrar"/>
                        </div>
                    </form>

                    <?php
                    include '../model/Administrador.php';
                    include '../controller/AdministradorController.php';

                    // verifica se há informação de produto vinda do formulário
                    if (isset($_POST["inputNome"])) {

                        $produtoForm = new Administrador();

                        $produtoForm->nome = $_POST["inputNome"];
                        $produtoForm->email = $_POST["inputEmail"];
                        $produtoForm->nivel = $_POST["inputNivel"];
                        $produtoForm->senha = $_POST["inputSenha"];

                        $produtoController = new AdministradorController();

                        $id = $produtoController->Inserir($produtoForm);


                        echo '<div class="row mt-4 m-2">';
                        echo '<div role="alert" class="col-md alert alert-success">';

                        echo '<h4>Dados do Administrador inserido</h4>';

                        echo "#ID: $id";
                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </div>





            <!-- Sticky Footer -->
            <?php include("footer.html"); ?>


            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>


            <!-- Logout Modal-->
            <?php include 'logoutModal.html'; ?>
        </div>

        <!-- Bootstrap core JavaScript-->
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Page level plugin JavaScript-->
        <script src="../vendor/chart.js/Chart.min.js"></script>
        <script src="../vendor/datatables/jquery.dataTables.js"></script>
        <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="../js/sb-admin.min.js"></script>

        <!-- Demo scripts for this page-->
        <script src="../js/demo/datatables-demo.js"></script>
        <script src="../js/demo/chart-area-demo.js"></script>

        <script src = 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js'></script>

    </body>

</html>
