<?php
if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
    if ($_SESSION["nivel"] == 1 || $_SESSION["nivel"] == 2) {

    } else {
        header('location: home.php');
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Controle - Cadastro Pessoa</title>

        <!-- Custom fonts for this template-->
        <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="../css/sb-admin.css" rel="stylesheet">

    </head>

    <body id="page-top">

        <!--Cabeçalho-->
        <?php include('header.html'); ?>
        <div id="wrapper">

            <!-- Sidebar -->
            <?php include('sidebar.php'); ?>

            <div class=" card mb-3" style="width: 100%;">
                <div class="card-header"><span class="display-4">Cadastro de Pessoa</span></div>
                <div class="card-body">
                    <form method="post" id="formCadastro">
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="form-label-group">
                                        <input type="text" id="inputNome" name="inputNome" class="form-control" placeholder="Nome Completo" required="required" autofocus="autofocus">
                                        <label for="inputNome">Nome Completo</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-label-group">
                                        <input type="text" id="inputCpf" name="inputCpf" data-mask="000.000.000-00" class="form-control" placeholder="CPF" required="required" >
                                        <label for="inputCpf">CPF</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="form-label-group">
                                        <input type="text" id="inputRg" name="inputRg" class="form-control" placeholder="RG" required="required">
                                        <label for="inputRg">RG</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-label-group">
                                        <input type="text" id="inputMatricula" name="inputMatricula" class="form-control" placeholder="Matrícula" required="required">
                                        <label for="inputMatricula">Matrícula</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="form-label-group">
                                        <input type="date" id="inputDataNascimento" name="inputDataNascimento" class="form-control" required="required">
                                        <label for="inputDataNascimento">Data de nascimento</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group" >
                                        <div class="form-control btn-group btn-group-toggle d-flex justify-content-around" style="height:auto;" data-toggle="buttons">
                                            <label class="btn btn-primary mb-0">
                                                <input type="radio" id="inputAluno" name="inputFuncao" value='a' required
                                                       > Aluno
                                            </label>
                                            <label class="btn btn-primary mb-0">
                                                <input type="radio" id="inputFuncionario" name="inputFuncao" value='f' required
                                                       > Funcionário
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center flex-column">
                            <input  type="submit" id="btnEnviar" class="btn btn-success btn-block align-self-center" style="width: 50%;" href="" value="Cadastrar"/>                            <small class="form-text text-muted align-self-center">Preencha os campos Rg e Matrícula sem traços ou marcações.</small>
                        </div>
                    </form>

                </div>
            </div>
            <?php
            include '../model/Pessoa.php';
            include '../controller/PessoaController.php';

            // verifica se há informação de produto vinda do formulário
            if (isset($_POST["inputNome"])) {

                $AdmForm = new Pessoa();

                $AdmForm->rg = $_POST["inputRg"];
                $AdmForm->matricula = $_POST["inputMatricula"];
                $cpf = $_POST["inputCpf"];
                $cpf = str_replace('.', '', $cpf);
                $cpf = str_replace('/', '', $cpf);
                $cpf = str_replace('-', '', $cpf);
                $AdmForm->cpf = $cpf;
                $AdmForm->nomePessoa = $_POST["inputNome"];
                $AdmForm->dataNascimento = $_POST["inputDataNascimento"];
                $AdmForm->funcao = $_POST["inputFuncao"];

                $AdmController = new PessoaController();

                if (strlen($cpf) == 11) {
                    if ($_POST["inputFuncao"] == 'a' || $_POST["inputFuncao"] == 'f') {
                        if (isset($_POST["inputDataNascimento"])) {
                            $id = $AdmController->Inserir($AdmForm);
                        }
                    }
                }

                /*
                  if (!is_null($id)) {
                  echo '                    <div class="row mt-4 mx-2">
                  <div role="alert" class="col-md alert alert-success">Cadastro de [5] Beto efetuado com sucesso!</div>
                  </div>';
                  }
                 */
            }
            ?>

            <!-- Sticky Footer -->
            <?php include("footer.html"); ?>


            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>


            <!-- Logout Modal-->
            <?php include 'logoutModal.html'; ?>
        </div>

        <!-- Bootstrap core JavaScript-->
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Page level plugin JavaScript-->
        <script src="../vendor/chart.js/Chart.min.js"></script>
        <script src="../vendor/datatables/jquery.dataTables.js"></script>
        <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="../js/sb-admin.min.js"></script>

        <!-- Demo scripts for this page-->
        <script src="../js/demo/datatables-demo.js"></script>
        <script src="../js/demo/chart-area-demo.js"></script>

        <script src = 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js'></script>

    </body>

</html>
