<?php

if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
}

include '../controller/AdministradorController.php';

$administradorController = new AdministradorController();

$idAdministrador= $_SESSION["idAdministrador"];
$nome = $_POST['inputNome'];
$email = $_POST["inputEmail"];
$senhaAtual = $_POST["inputSenha"];
$senhaNova = $_POST["inputNovaSenha"];

$editar=$administradorController->Atualizar($idAdministrador,$nome,$email,$senhaAtual,$senhaNova);

if($editar==0){
    session_unset();
    //Destruindo a sessão:
    session_destroy();
    
    header('location:login.php?editado');
}else{
    header('location:editarAdministrador.php?naoeditado');
}


