<?php

header('Cache-Control: no-cache');
header('Content-type: application/json; charset="utf-8"', true);

// Desative esse bloco para exibir todos os erros
/* ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL); */
require_once ('../model/Passagem.php');
require_once ('../controller/PassagemController.php');

$passagem = new PassagemController();

$idPessoa = $_REQUEST['idPessoa'];

$passagem = $passagem->SelecionarPorIdPessoa($idPessoa);

echo( json_encode($passagem) );
?>