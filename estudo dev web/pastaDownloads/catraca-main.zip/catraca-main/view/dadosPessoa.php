<?php
if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Controle - Perfil</title>

        <!-- Custom fonts for this template-->
        <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="../css/sb-admin.css" rel="stylesheet">

    </head>

    <body id="page-top">

        <!--Cabeçalho-->
        <?php
        include('header.html');
        include '../model/Pessoa.php';
        include '../controller/PessoaController.php';

        $pessoaController = new PessoaController();

        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        ?>

        <div id="wrapper">

            <!-- Sidebar -->
            <?php include('sidebar.php'); ?>

            <div class="card mb-3" style="width: 100%;">
                <div class="card-header"><span class="display-4">Pessoa</span></div>
                <div class="card card-body mb-3">
                    <div class="card border my-2 p-1" style="margin-bottom: 3rem !important">
                        <div class="row boarder">

                            <img class="rounded-circle col-sm m-2" style="max-height:200px; max-width: 200px; height: auto; width: auto; object-fit: contain;" alt="Foto do Usuário" src="../img/girl.png"/>

                            <div class="col-sm align-self-center">
                                <div class="card-body">
                                    <div class="form-row">
                                        <div class="form-group col-sm-10">
                                            <div class="form-label-group">
                                                <input type="text" id="inputNome" class="form-control bg-white" placeholder="Nome Completo" value="" readonly>
                                                <label for="inputNome">Nome Completo</label>
                                            </div>
                                        </div>
                                        <div class="form-group col-sm">
                                            <div class="form-label-group">
                                                <input type="text" id="inputFuncao" class="form-control bg-white" placeholder="Função" value="" readonly>
                                                <label for="inputFuncao">Função</label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-sm">
                                            <div class="form-label-group">
                                                <input type="text" id="inputMatricula" class="form-control bg-white" placeholder="Matrícula" value="" readonly>
                                                <label for="inputMatricula">Matrícula</label>
                                            </div>
                                        </div>
                                        <div class="form-group col-sm">
                                            <div class="form-label-group">
                                                <input type="text" id="inputCpf" class="form-control bg-white" placeholder="CPF" value="" readonly>
                                                <label for="inputCpf">CPF</label>
                                            </div>
                                        </div>
                                        <div class="form-group col-sm">
                                            <div class="form-label-group">
                                                <input type="text" id="inputRg" class="form-control bg-white" placeholder="RG" value="" readonly>
                                                <label for="inputRg">RG</label>
                                            </div>
                                        </div>
                                        <div class="form-group col-sm">
                                            <div class="form-label-group">
                                                <input type="date" id="inputDataNascimento" class="form-control bg-white" placeholder="Data de Nascimento" value="" readonly>
                                                <label for="inputDataNascimento">Data de Nascimento</label>
                                            </div>
                                        </div>
                                    </div>
                                    <?php if ($_SESSION["nivel"] == 1 || $_SESSION["nivel"] == 2) { ?>
                                        <div class="form-group mb-0 grupoBotoes"  style="display: none;">
                                            <div class="form-label-group">
                                                <a class="btn btn-warning btnPessoa" id="btnEditar" href="editarPessoa.php" style="padding: 0.4rem 3rem;">Editar Pessoa</a>
                                                <form method="post" action="excluirPessoa.php" style="display: inline-block">
                                                    <input id="inputIdPessoa" type="hidden" name="idPessoa" value=""/>
                                                    <input id="btnSubmitExcluir" type="submit" class="btn btn-danger btnPessoa" style="padding: 0.4rem 3rem;" value="Excluir Pessoa"/>
                                                </form>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>

                        <div class="border card m-2 p-1" >
                            <form class="form-row d-flex justify-content-between align-items-center">
                                <div class="form-group col-sm mb-0">
                                    <div class="form-label-group">
                                        <select id="selectMatricula" class="form-control bg-white custom-select custom-select-lg">
                                            <option value="0">-- * --</option>
                                            <?php
                                            // Busca os dados da tabela
                                            $todos = $pessoaController->SelecionarTodos();

                                            // Verifica se Ã© um vetor e se possui conteÃºdo
                                            if (is_array($todos) && sizeof($todos) > 0) {
                                                foreach ($todos as $pessoa) {
                                                    echo "<option value = \"$pessoa->idPessoa\">$pessoa->matricula : $pessoa->funcao</option>";
                                                }
                                                ?>
                                            <?php }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-sm-9 mb-0">
                                    <div class="form-label-group">
                                        <select id="selectPessoa" class="form-control bg-white custom-select custom-select-lg">
                                            <option value="0">-- Selecionar Pessoa --</option>
                                            <?php
                                            // Busca os dados da tabela
                                            $todos = $pessoaController->SelecionarTodos();

                                            // Verifica se Ã© um vetor e se possui conteÃºdo
                                            if (is_array($todos) && sizeof($todos) > 0) {
                                                foreach ($todos as $pessoa) {
                                                    echo "<option value = \"$pessoa->idPessoa\">$pessoa->nomePessoa</option>";
                                                }
                                                ?>
                                            <?php }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="card-header">
                            <i class="fas fa-table"></i>
                            Tabela de Pessoas</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Passagem</th>
                                            <th>Data e Hora</th>
                                        </tr>
                                    </thead>

                                    <tbody id="bodyTabelaPassagens">

                                    </tbody>

                                    <tfoot>
                                        <tr>
                                            <th>ID Passagem</th>
                                            <th>Data e Hora</th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sticky Footer -->
        <?php include 'footer.html'; ?>

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>


        <!-- Logout Modal-->
        <?php include 'logoutModal.html'; ?>

        <!-- Modal Excluir -->
        <div class="modal fade" id="confirm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Exclusão de Pessoa</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Selecione "Excluir" se você deseja excluir essa pessoa.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-primary" id="delete">Excluir</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bootstrap core JavaScript-->
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Page level plugin JavaScript-->
        <script src="../vendor/chart.js/Chart.min.js"></script>
        <script src="../vendor/datatables/jquery.dataTables.js"></script>
        <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="../js/sb-admin.min.js"></script>

        <!-- Demo scripts for this page
       <script src="../js/demo/datatables-demo.js"></script>
        <script src="../js/demo/chart-area-demo.js"></script>-->

        <script src = 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js'></script>

        <script>
            $(document).ready(function() {

                //Limpando os valores preenchidos
                $("#selectPessoa").val("0");
                $("#selectMatricula").val("0");

                $("#inputNome").val("");
                $("#inputCpf").val("");
                $("#inputRg").val("");
                $("#inputDataNascimento").val("");
                $("#inputMatricula").val("");
                $("#inputFuncao").val("");
                $("#btnEditar").attr("href", "editarPessoa.php");
                $("#inputIdPessoa").val("");


                (function($) {

                    $.fn.mudarDados = function() {
                        var idPessoa = $(this).val();
                        console.log(idPessoa);

                        if (idPessoa === "0") {
                            $(".grupoBotoes").css("display", "none");
                        } else {
                            $(".grupoBotoes").css("display", "block");
                        }

                        $.get("dadosPessoa.ajax.php",
                                {idPessoa: idPessoa})
                                .done(function(data) {
                                    console.log(data);
                                    $("#inputNome").val(data.nomePessoa);
                                    $("#inputCpf").val(data.cpf);
                                    $("#inputRg").val(data.rg);
                                    $("#inputDataNascimento").val(data.dataNascimento);
                                    $("#inputMatricula").val(data.matricula);
                                    if (data.funcao == "a") {
                                        $("#inputFuncao").val("Aluno");
                                    } else if (data.funcao == "f") {
                                        $("#inputFuncao").val("Funcionário");
                                    }
                                    $("#btnEditar").attr("href", "editarPessoa.php?idPessoa=" + data.idPessoa);
                                    $("#inputIdPessoa").val(data.idPessoa);
                                });

                        $.get("passagensPessoa.ajax.php",
                                {idPessoa: idPessoa})
                                .done(function(data) {
                                    //console.log(data);

                                    $("#bodyTabelaPassagens").html("");

                                    for (index = 0; index < data.length; ++index) {
                                        console.log(data[index]);
                                        $("#bodyTabelaPassagens").prepend(
                                                "<tr>" +
                                                "  <td scope=\"row\">" + data[index].idPassagem + "</td>" +
                                                "  <td scope=\"row\">" + data[index].dataHora + "</td>" +
                                                "</tr>"
                                                );
                                    }

                                }
                                );
                    };
                })(jQuery);

                $("#selectMatricula").change(function() {
                    $("#selectPessoa").val($(this).val());
                    $(this).mudarDados();
                });
                $("#selectPessoa").change(function() {
                    $("#selectMatricula").val($(this).val());
                    $(this).mudarDados();
                });

                $('.inputCpf').mask('000.000.000-00', {reverse: true});

                //Exibir Modal
                $('#btnSubmitExcluir').on('click', function(e) {
                    var $form = $(this).closest('form');
                    e.preventDefault();
                    $('#confirm').modal({
                        backdrop: 'static',
                        keyboard: false
                    })
                            .on('click', '#delete', function(e) {
                                $form.trigger('submit');
                            });
                });

            });

        </script>

    </body>

</html>
