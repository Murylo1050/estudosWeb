<?php
if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    } else {
        if ($_SESSION["nivel"] != 1) {
            header('location: home.php');
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Controle - Perfil</title>

        <!-- Custom fonts for this template-->
        <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="../css/sb-admin.css" rel="stylesheet">

    </head>

    <body id="page-top">

        <!--Cabeçalho-->
        <?php
        include('header.html');
        include '../model/Administrador.php';
        include '../controller/AdministradorController.php';

        /* Cria uma nova instÃ¢ncia do controlador para acessar as funÃ§Ãµes
          de acesso a dados */
        $administradorController = new AdministradorController();

        // Busca os dados da tabela
        $todos = $administradorController->SelecionarTodos();
        ?>


        <div id="wrapper">

            <!-- Sidebar -->
            <?php include('sidebar.php'); ?>

            <div class="card mb-3" style="width: 100%;">
                <div class="card-header"><span class="display-4">Lista de Admins</span></div>
                <div class="card card-body mb-3">
                    <div class="card border my-2 p-1" style="margin-bottom: 3rem !important">
                        <div class="card-header">
                            <i class="fas fa-table"></i>
                            Tabela de Admins</div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID Admin</th>
                                            <th>Nome</th>
                                            <th>Nível</th>
                                            <th>Email</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>

                                    <tfoot>
                                        <tr>
                                            <th>ID Admin</th>
                                            <th>Nome</th>
                                            <th>Nível</th>
                                            <th>Email</th>
                                            <th>Ações</th>
                                        </tr>
                                    </tfoot>

                                    <tbody>
                                        <?php
                                        foreach ($todos as $Adm) {
                                            if ($Adm->idAdministrador != $_SESSION['idAdministrador']) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $Adm->idAdministrador; ?></td>
                                                    <td><?php echo $Adm->nome; ?></td>
                                                    <td><?php echo $Adm->nivel; ?></td>
                                                    <td><?php echo $Adm->email; ?></td>

                                                    <td class="d-flex justify-content-center"><form method="post" action="excluirAdm.php" onsubmit=""><input type="hidden" name="idAdministrador" value="<?php echo $Adm->idAdministrador; ?>"/> <input type="submit" class="btn btn-danger btn-block" value="Excluir"/></form></td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        ?>

                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <!-- Sticky Footer -->
<?php include 'footer.html'; ?>

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>


        <!-- Logout Modal-->
<?php include 'logoutModal.html'; ?>

        <!-- Modal Excluir -->
        <div class="modal fade" id="confirm" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Exclusão de Admin</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Selecione "Excluir" se você deseja excluir esse Administrador.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
                        <button class="btn btn-primary" id="delete">Excluir</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bootstrap core JavaScript-->
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Page level plugin JavaScript-->
        <script src="../vendor/chart.js/Chart.min.js"></script>
        <script src="../vendor/datatables/jquery.dataTables.js"></script>
        <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="../js/sb-admin.min.js"></script>

        <!-- Demo scripts for this page
        <script src="../js/demo/datatables-demo.js"></script>
        <script src="../js/demo/chart-area-demo.js"></script>-->

        <script src = 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js'></script>

        <script>
            //Exibir Modal
            $(document).ready(function() {
                /*
                 $.fn.exibirModalExcluir = function(){
                 var submitForm = $(this).parent();
                 console.log(submitExcluir);

                 $(this).on('click', function (e) {

                 var $form = $(this).closest('form');
                 e.preventDefault();
                 $('#confirm').modal({

                 backdrop: 'static',
                 keyboard: false

                 })
                 .on('click', '#delete', function (e) {
                 $form.trigger('submit');
                 });

                 });

                 };

                 exibirModalExcluirAux(){
                 $("")
                 }
                 */
            });
        </script>
    </body>

</html>





