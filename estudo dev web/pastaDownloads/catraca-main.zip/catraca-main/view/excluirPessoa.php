<?php

if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
    if ($_SESSION["nivel"] == 1 || $_SESSION["nivel"] == 2) {

    } else {
        header('location: home.php');
    }
}

require_once '../model/Pessoa.php';
require_once '../controller/PessoaController.php';

$administradorController = new PessoaController();


if (isset($_POST["idPessoa"])) {

    $idAdm = $_POST["idPessoa"];
    $administradorController->Excluir($idAdm);
}

header('location: dadosPessoa.php');
?>