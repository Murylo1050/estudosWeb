<?php

header('Cache-Control: no-cache');
header('Content-type: application/json; charset="utf-8"', true);

// Desative esse bloco para exibir todos os erros
/* ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL); */
require_once ('../model/Administrador.php');
require_once ('../controller/AdministradorController.php');

$administradorController = new AdministradorController();

if (isset($_GET['senha'])) {
    $senha = $_GET['senha'];

    if (isset($_GET['login'])) {
        $login = $_GET['login'];

        if (filter_var($login, FILTER_VALIDATE_EMAIL)) {
            $administrador = $administradorController->SelecionarPorEmailSenha($login, $senha);
        } else {
            $administrador = $administradorController->SelecionarPorIdSenha($login, $senha);
        }
    }
}

echo( json_encode($administrador) );
?>