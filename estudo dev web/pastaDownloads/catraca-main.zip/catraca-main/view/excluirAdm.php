<?php

if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
    if ($_SESSION["nivel"] != 1) {
        header('location: home.php');
    }
}

require_once '../model/Administrador.php';
require_once '../controller/AdministradorController.php';

$administradorController = new AdministradorController();


if (isset($_POST["idAdministrador"])) {

    $idAdm = $_POST["idAdministrador"];
    $administradorController->Excluir($idAdm);
}

header('location: listaAdm.php');
?>