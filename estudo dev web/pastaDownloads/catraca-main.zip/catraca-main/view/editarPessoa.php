<?php
if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
    if ($_SESSION["nivel"] == 1 || $_SESSION["nivel"] == 2) {

    } else {
        header('location: home.php');
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Controle - Perfil</title>

        <!-- Custom fonts for this template-->
        <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="../css/sb-admin.css" rel="stylesheet">

    </head>

    <body id="page-top">

        <!--Cabeçalho-->
        <?php
        include('header.html');
        include '../model/Pessoa.php';
        include '../controller/PessoaController.php';
        $pessoaController = new PessoaController();
        ?>

        <div id="wrapper">

            <!-- Sidebar -->
            <?php include('sidebar.php'); ?>

            <div class="card mb-3" style="width: 100%;">
                <div class="card-header"><span class="display-4">Editar Pessoa</span></div>
                <div class="card card-body mb-3">
                    <div class="card border my-2 p-1" style="margin-bottom: 3rem !important">
                        <div class="row boarder">

                            <img class="rounded-circle col-sm m-2" style="max-height:200px; max-width: 200px; height: auto; width: auto; object-fit: contain;" alt="Foto do Usuário" src="../img/girl.png"/>


                            <div class="col-sm align-self-center">
                                <div class="card-body">
                                    <?php
                                    if (isset($_GET["idPessoa"])) {
                                        $Pessoa = new Pessoa();
                                        $idPessoa = $_GET["idPessoa"];
                                        $Pessoa = $pessoaController->SelecionarPorId($idPessoa);
                                    }
                                    ?>
                                    <form method="post" action="editarPessoa.php?idPessoa=<?php echo $Pessoa->idPessoa ?>">
                                        <div class="form-row">
                                            <div class="form-group col-sm-8">
                                                <div class="form-label-group">
                                                    <input type="text" id="inputNome" name="inputNome" class="form-control bg-white" placeholder="Nome Completo" value="<?php echo $Pessoa->nomePessoa ?>">
                                                    <label for="inputNome">Nome Completo</label>
                                                </div>
                                            </div>
                                            <div class="col-md">
                                                <div class="form-group" >
                                                    <div class="form-control btn-group btn-group-toggle d-flex justify-content-around" style="height:auto;" data-toggle="buttons">
                                                        <label class="btn btn-primary mb-0 <?php
                                                        if ($Pessoa->funcao == 'a') {
                                                            echo ' active ';
                                                        }
                                                        ?>">
                                                            <input type="radio" id="inputAluno" name="inputFuncao" value="a" required <?php
                                                            if ($Pessoa->funcao == 'a') {
                                                                echo 'checked ';
                                                            }
                                                            ?>
                                                                   > Aluno
                                                        </label>
                                                        <label class="btn btn-primary mb-0 <?php
                                                        if ($Pessoa->funcao == 'f') {
                                                            echo ' active ';
                                                        }
                                                        ?>">
                                                            <input type="radio" id="inputFuncionario" name="inputFuncao" value="f" required <?php
                                                            if ($Pessoa->funcao == 'f') {
                                                                echo 'checked ';
                                                            }
                                                            ?>
                                                                   > Funcionário
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-sm">
                                                <div class="form-label-group">
                                                    <input type="text" id="inputMatricula" name="inputMatricula" class="form-control bg-white" placeholder="Matrícula" value="<?php echo $Pessoa->matricula ?>">
                                                    <label for="inputMatricula">Matrícula</label>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm">
                                                <div class="form-label-group">
                                                    <input type="text" id="inputCpf" name="inputCpf" data-mask="000.000.000-00" class="form-control bg-white" placeholder="CPF" value="<?php echo $Pessoa->cpf ?>" data-mask='000.000.000-00'>
                                                    <label for="inputCpf">CPF</label>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm">
                                                <div class="form-label-group">
                                                    <input type="text" id="inputRg" name="inputRg" class="form-control bg-white" placeholder="RG" value="<?php echo $Pessoa->rg ?>">
                                                    <label for="inputRg">RG</label>
                                                </div>
                                            </div>
                                            <div class="form-group col-sm">
                                                <div class="form-label-group">
                                                    <input type="date" id="inputDataNascimento" name="inputDataNascimento" class="form-control bg-white" placeholder="Data de Nascimento" value="<?php echo $Pessoa->dataNascimento ?>" >
                                                    <label for="inputDataNascimento">Data de Nascimento</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group mb-0">
                                            <div class="form-label-group">
                                                <input class="btn btn-success" id="btnEnviar" type="submit" style="padding: 0.4rem 3rem;" value="Editar Pessoa"/>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                    // verifica se há informação de produto vinda do formulário
                    if (isset($_POST["inputNome"])) {

                        $AdmForm = new Pessoa();

                        $AdmForm->idPessoa = $_GET["idPessoa"];
                        $AdmForm->rg = $_POST["inputRg"];
                        $AdmForm->matricula = $_POST["inputMatricula"];
                        $cpf = $_POST["inputCpf"];
                        $cpf = str_replace('.', '', $cpf);
                        $cpf = str_replace('/', '', $cpf);
                        $cpf = str_replace('-', '', $cpf);
                        $AdmForm->cpf = $cpf;
                        $AdmForm->nomePessoa = $_POST["inputNome"];
                        $AdmForm->dataNascimento = $_POST["inputDataNascimento"];
                        $AdmForm->funcao = $_POST["inputFuncao"];

                        $AdmController = new PessoaController();


                        if (strlen($cpf) == 11) {
                            if ($_POST["inputFuncao"] == 'a' || $_POST["inputFuncao"] == 'f') {
                                if (isset($_POST["inputDataNascimento"])) {
                                    $AdmController->Atualizar($AdmForm);
                                }
                            }
                        }

                        echo'<script>'
                        . 'window . location . replace("dadosPessoa.php");'
                        . '</script>';


                        /*
                          echo '<div class="row mx-2 mt-1">';
                          echo '<div role="alert" class="col-md alert alert-success">';

                          echo '<h4>Dados do Administrador atualizados</h4>';

                          echo "#ID: $AdmForm->idPessoa";
                          echo '<br><a href="dadosPessoa.php">Voltar à lista</a>';
                          echo '</div>';
                          echo '</div>';
                         */
                    }
                    ?>
                </div>
            </div>
        </div>




        <!-- Sticky Footer -->
        <?php include 'footer.html'; ?>

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>


        <!-- Logout Modal-->
        <?php include 'logoutModal.html'; ?>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="../vendor/jquery/jquery.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="../vendor/chart.js/Chart.min.js"></script>
    <script src="../vendor/datatables/jquery.dataTables.js"></script>
    <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="../js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="../js/demo/datatables-demo.js"></script>
    <script src="../js/demo/chart-area-demo.js"></script>

    <script src = 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js'></script>

</body>

</html>
