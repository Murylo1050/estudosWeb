<?php
if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
    if (is_null($_SESSION['idAdministrador']) || $_SESSION['idAdministrador'] == "") {
        header('location: logout.php');
    }
    /*
    if ($_SESSION["nivel"] != 1) {
        header('location: home.php');
    }*/
}
?>

<!DOCTYPE html>
<html lang="pt-br">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Controle - Editar Perfil</title>

        <!-- Custom fonts for this template-->
        <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

        <!-- Page level plugin CSS-->
        <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

        <!-- Custom styles for this template-->
        <link href="../css/sb-admin.css" rel="stylesheet">
        
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" ></script>
        <script type="text/javascript">
            $(function () {
                $("#formEditar").submit(function () {                    
                    if ($('#inputNovaSenha').val() === $('#inputSenhaConfirm').val()) {
                        return true;
                    }else{
                        alert("Senhas diferentes!");
                        return false;
                    }
                });              
            });
        </script>

    </head>

    <body id="page-top">

        <!--Cabeçalho-->
        <?php include('header.html'); ?>
        <div id="wrapper">

            <!-- Sidebar -->
            <?php include('sidebar.php'); ?>

            <div class=" card mb-3" style="width: 100%;">
                <div class="card-header"><span class="display-4">Editar Perfil</span></div>
                <div class="card-body">
                    <form action="editarAdm.php" method="post" id="formEditar">
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-9">
                                    <div class="form-label-group">
                                        <input type="text" id="inputNome" name="inputNome" class="bg-white form-control" placeholder="Nome Completo" autofocus="autofocus"
                                               value="<?php echo $_SESSION['nome'] ?>">
                                        <label for="inputNome">Nome Completo</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <div class="form-label-group">
                                        <input type="number" min="1" max="3" id="inputNivel" name="inputNivel" class="bg-white form-control" placeholder="Nível" disabled="disabled" readonly
                                               value="<?php echo $_SESSION['nivel'] ?>">
                                        <label for="inputNivel">Nível</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-7">
                                    <div class="form-label-group">
                                        <input type="Email" id="inputEmail" name="inputEmail" class="bg-white form-control" placeholder="Email"
                                               value="<?php echo $_SESSION['email'] ?>"/>
                                        <label for="inputEmail">Email</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <div class="form-label-group">
                                        <input type="password" id="inputSenha" name="inputSenha" class="bg-white form-control" placeholder="Senha atual"/>
                                        <label for="inputSenha">Senha atual</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <li class="dropdown-divider mx-2" style="border-top-color: gainsboro;"></li>
                        <div class="form-group mt-3">
                            <div class="form-row">
                                <div class="col-md">
                                    <div class="form-label-group">
                                        <input type="password" id="inputNovaSenha" name="inputNovaSenha" class="bg-white form-control" placeholder="Nova senha">
                                        <label for="inputNovaSenha">Nova senha</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mt-3">
                            <div class="form-row">
                                <div class="col-md">
                                    <div class="form-label-group">
                                        <input type="password" id="inputSenhaConfirm" name="inputSenhaConfirm" class="bg-white form-control" placeholder="Confirmar senha">
                                        <label for="inputSenhaConfirm">Confirmar senha</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mt-2">
                            <div class="form-row">
                                <div class="col-md d-flex justify-content-center">
                                    <input id="btnEnviar" type="submit" class="btn btn-success btn-block" value="Enviar" style="width: 50%"/>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>


            <!-- Sticky Footer -->
            <?php include("footer.html"); ?>

            <!-- Scroll to Top Button-->
            <a class="scroll-to-top rounded" href="#page-top">
                <i class="fas fa-angle-up"></i>
            </a>


            <!-- Logout Modal-->
            <?php include 'logoutModal.html'; ?>

        </div>

        <!-- Bootstrap core JavaScript-->
        <script src="../vendor/jquery/jquery.min.js"></script>
        <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

        <!-- Core plugin JavaScript-->
        <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

        <!-- Page level plugin JavaScript-->
        <script src="../vendor/chart.js/Chart.min.js"></script>
        <script src="../vendor/datatables/jquery.dataTables.js"></script>
        <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

        <!-- Custom scripts for all pages-->
        <script src="../js/sb-admin.min.js"></script>

        <!-- Demo scripts for this page-->
        <script src="../js/demo/datatables-demo.js"></script>
        <script src="../js/demo/chart-area-demo.js"></script>

        <script src = 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.min.js'></script>

    </body>

</html>
