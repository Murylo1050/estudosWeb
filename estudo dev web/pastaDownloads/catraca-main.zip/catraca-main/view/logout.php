<?php

if (session_status() !== PHP_SESSION_ACTIVE) {//Verificar se a sessão não já está aberta.
    session_start();
}

// limpe tudo que for necessário na saída.
// Eu geralmente não destruo a seção, mas invalido os dados da mesma
// para evitar algum "necromancer" recuperar dados. Mas simplifiquemos:
session_destroy();
header("location: login.php");
exit();
