<?php

class Administrador {

    var $idAdministrador;
    var $nome;
    var $nivel;
    var $email;
    var $senha;

    //var $status;
}
