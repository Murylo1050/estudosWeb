<?php

class Passagem {

var $idPassagem;
var $idPassagemPessoa;
var $dataHora;
var $nomePessoa;
}