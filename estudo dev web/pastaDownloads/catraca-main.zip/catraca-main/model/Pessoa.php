<?php

class Pessoa {

var $idPessoa;
var $rg;
var $matricula;
var $cpf;
var $nomePessoa;
var $dataNascimento;
var $funcao;

}