use db_catraca;

select * from tb_administrador;

SELECT `idAdministrador`,`nomeAdministrador`,`nivel`,`email`,`senha` FROM tb_administrador
WHERE `idAdministrador` = 1;

insert into tb_administrador (idAdministrador, nome, nivel, email, senha, status) values (null, 'Antonio', 1, 'antonio@gmail.com', '$2y$12$GSy4rlddO9NtNhhoWAWRYe6WlBcswj.2R.pk8j2QvOzsy5ZD32ht2', 'a');

select* from tb_pessoa order by matricula;

select * from tb_passagem;

SELECT `idPassagem`,`idPassagemPessoa`,`dataHora`, `nomePessoa` FROM tb_passagem
                inner join tb_pessoa on idPassagemPessoa = idPessoa
WHERE dataHora LIKE '2019-02-02%' and
tb_pessoa.status = 'a'
                order by dataHora asc;