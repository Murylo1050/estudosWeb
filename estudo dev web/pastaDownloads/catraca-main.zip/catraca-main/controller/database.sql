create database if not exists db_catraca;

use db_catraca;

create table tb_pessoa(
idPessoa int auto_increment primary key,
rg varchar(14) unique,
matricula varchar(10) not null,
cpf varchar(11) unique not null,
nomePessoa varchar(50) not null,
dataNascimento date,
funcao char(1) not null check(funcao = 'a' or funcao = 'f'), -- aluno ou funcionario
status char(1) check(status = 'a' or status = 'i') -- ativo ou inativo
);

create table tb_administrador(
idAdministrador int auto_increment primary key,
nome varchar(50) not null,
nivel int check(nivel >=1 and nivel <=3), -- Administrador, Secretaria, Porteiro
email varchar(256) not null unique,
senha varchar(60) not null,
status char(1) check(status = 'a' or status = 'i') -- ativo ou inativo
);

create table tb_passagem(
idPassagem int auto_increment primary key,
idPassagemPessoa int not null,
constraint fk_passagem_pessoa foreign key(idPassagemPessoa) references tb_pessoa(idPessoa),
dataHora datetime not null
);