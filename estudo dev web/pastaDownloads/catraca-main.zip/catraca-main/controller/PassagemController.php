<?php

require_once 'Banco.php';

class PassagemController extends Banco {

    private $tabela = "tb_passagem";
    private $conexao;
    private $sql;

    function SelecionarTodos() {

        // Abre a conxão com o banco de dados
        $this->conexao = parent::Conexao();

        // Montar a consulta(query) do banco de dados de todos os pessoas
        $this->sql = "SELECT `idPassagem`,`idPassagemPessoa`,`dataHora` "
                . "FROM $this->tabela";

        // Executa o comando do banco de dados
        $busca = mysqli_query($this->conexao, $this->sql);

        $listaPassagens = array();

        // Recupera um vetor a partir dos resultados
        while ($dadoPassagem = mysqli_fetch_array($busca)) {
            // Nova instância do pessoa
            $prod = new Passagem();
            // Preencher os atributos com as informações do banco de dados
            $prod->idPassagem = $dadoPassagem["idPassagem"];
            $prod->idPassagemPessoa = $dadoPassagem["idPassagemPessoa"];
            $prod->dataHora = $dadoPassagem["dataHora"];


            // Cria a lista de pessoas e adiciona mais um item
            $listaPassagens[] = $prod;
        }

        return $listaPassagens;
    }

    function SelecionarPorIdPessoa($idPessoa) {

        $this->conexao = parent::Conexao();
        $this->sql = "SELECT `idPassagem`,`idPassagemPessoa`,`dataHora` "
                . " FROM $this->tabela WHERE idPassagemPessoa = '$idPessoa'";

        // Executa o comando do banco de dados
        $busca = mysqli_query($this->conexao, $this->sql);

        $listaPassagens = array();

        // Recupera um vetor a partir dos resultados
        while ($dadoPassagem = mysqli_fetch_array($busca)) {
            // Nova instância do pessoa
            $prod = new Passagem();
            // Preencher os atributos com as informações do banco de dados
            $prod->idPassagem = $dadoPassagem["idPassagem"];
            $prod->idPassagemPessoa = $dadoPassagem["idPassagemPessoa"];
            $prod->dataHora = $dadoPassagem["dataHora"];


            // Cria a lista de pessoas e adiciona mais um item
            $listaPassagens[] = $prod;
        }

        return $listaPassagens;
    }

    function SelecionarPorData($data) {

        $this->conexao = parent::Conexao();
        $this->sql = "SELECT `idPassagem`,`idPassagemPessoa`,`dataHora`, `nomePessoa` FROM $this->tabela "
                . "inner join tb_pessoa on idPassagemPessoa = idPessoa "
                . " WHERE dataHora LIKE '2019-10-02%' and tb_pessoa.status = 'a' "
                . " order by dataHora asc";

        // Executa o comando do banco de dados
        $busca = mysqli_query($this->conexao, $this->sql);

        $listaPassagens = array();

        // Recupera um vetor a partir dos resultados
        while ($dadoPassagem = mysqli_fetch_array($busca)) {
            // Nova instância do pessoa
            $prod = new Passagem();
            // Preencher os atributos com as informações do banco de dados
            $prod->idPassagem = $dadoPassagem["idPassagem"];
            $prod->idPassagemPessoa = $dadoPassagem["idPassagemPessoa"];
            $prod->nomePessoa = $dadoPassagem["nomePessoa"];
            $prod->dataHora = $dadoPassagem["dataHora"];


            // Cria a lista de pessoas e adiciona mais um item
            $listaPassagens[] = $prod;
        }

        return $listaPassagens;
    }

    function Inserir(Passagem $passagem) {
        $this->conexao = parent::Conexao();
        $this->sql = "INSERT INTO  $this->tabela "
                . "VALUES(null, "
                . "'$passagem->idPassagemPessoa', "
                . "'$passagem->dataHora');";

        $this->conexao->query($this->sql);
        return $this->conexao->insert_id;
    }

}
