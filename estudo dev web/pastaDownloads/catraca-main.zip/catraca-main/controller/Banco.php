<?php

class Banco {

    var $usuario = "";
    var $senha = "";
    var $banco = "";
    var $servidor = "localhost";

    function Conexao() {
        $conexao = new mysqli($this->servidor, $this->usuario, $this->senha, $this->banco);

        // Verificar conexão
        if (!$conexao) {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }
        return $conexao;
    }

}
