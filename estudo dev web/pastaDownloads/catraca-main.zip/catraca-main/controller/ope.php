<?php

//Verificar se a sessão não já está aberta.
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once 'Banco.php';

include '../model/Administrador.php';
include '../controller/AdministradorController.php';


$login = $_POST['inputIdEmail'];
$senha = $_POST['inputSenha'];

$administradorController = new AdministradorController();

function checkEmail($email) {
    $find1 = strpos($email, '@');
    $find2 = strpos($email, '.');
    return ($find1 !== false && $find2 !== false && $find2 > $find1);
}

if (checkEmail($login)) {
    $loginAdministrador = $administradorController->SelecionarPorEmailSenha($login, $senha);
} else {
    $loginAdministrador = $administradorController->SelecionarPorIdSenha($login, $senha);
}

//var_dump($loginAdministrador);
//var_dump($_POST['inputIdEmail']);
//var_dump($_POST['inputSenha']);


if (!is_null($loginAdministrador)) { //Verificar se a pesquisa retornou algum valor não nulo
    $_SESSION['idAdministrador'] = $loginAdministrador->idAdministrador;
    $_SESSION['nome'] = $loginAdministrador->nome;
    $_SESSION['nivel'] = $loginAdministrador->nivel;
    $_SESSION['email'] = $loginAdministrador->email;

    //NÃO SALVAR A SENHA NA SESSÃO, POR FAVOR, NÉ??????
    header('location: ../view/home.php');
} else {
    //Apagando todos os dados da sessão:
    session_unset();
    //Destruindo a sessão:
    session_destroy();
    header('location: ../view/login.php');
}
?>