<?php

require_once 'Banco.php';

class AdministradorController extends Banco {

    private $tabela = "tb_administrador";
    private $conexao;
    private $sql;

    function SelecionarTodos() {

        // Abre a conxão com o banco de dados
        $this->conexao = parent::Conexao();

        // Montar a consulta(query) do banco de dados de todos os pessoas
        $this->sql = "SELECT `idAdministrador`,`nivel`,`nome`,`email`, `status`"
                . "FROM $this->tabela where status = 'a'";

        // Executa o comando do banco de dados
        $busca = mysqli_query($this->conexao, $this->sql);

        $listaPessoas = array();

        // Recupera um vetor a partir dos resultados
        while ($dadoPessoa = mysqli_fetch_array($busca)) {
            // Nova instância do pessoa
            $pessoa = new Administrador();
            // Preencher os atributos com as informações do banco de dados
            $pessoa->idAdministrador = $dadoPessoa["idAdministrador"];
            $pessoa->nivel = $dadoPessoa["nivel"];
            $pessoa->nome = $dadoPessoa["nome"];
            $pessoa->email = $dadoPessoa["email"];
            $pessoa->status = $dadoPessoa["status"];



            // Cria a lista de pessoas e adiciona mais um item
            $listaPessoas[] = $pessoa;
        }

        return $listaPessoas;
    }

    function SelecionarPorIdSenha($idAdministrador, $senhaAdministrador) {

        //Abre conexão com o banco de Dados
        $this->conexao = parent::Conexao();

        //Montar a consulta do Banco de Dados por Id e Senha
        $this->sql = "SELECT `idAdministrador`,`nome`,`nivel`,`email`,`senha` FROM $this->tabela WHERE `idAdministrador` = $idAdministrador and `status` = 'a';";

        $busca = $this->conexao->query($this->sql);

        $resultado = mysqli_fetch_row($busca);

        if ((password_verify($senhaAdministrador, $resultado[4]))) {

            $AdministradorForm = new Administrador();
            $AdministradorForm->idAdministrador = $resultado[0];
            $AdministradorForm->nome = $resultado[1];
            $AdministradorForm->nivel = $resultado[2];
            $AdministradorForm->email = $resultado[3];
            $AdministradorForm->senha = $resultado[4];

            return $AdministradorForm;
        }
    }

    function SelecionarPorEmailSenha($emailAdm, $senhaAdministrador) {

        //Abre conexão com o banco de Dados
        $this->conexao = parent::Conexao();

        //Montar a consulta do Banco de Dados por Id e Senha
        $this->sql = "SELECT `idAdministrador`,`nome`,`nivel`,`email`,`senha` FROM $this->tabela WHERE `email` = '$emailAdm' and `status` = 'a';";

        $busca = $this->conexao->query($this->sql);

        $resultado = mysqli_fetch_row($busca);

        if ((password_verify($senhaAdministrador, $resultado[4]))) {

            $AdministradorForm = new Administrador();
            $AdministradorForm->idAdministrador = $resultado[0];
            $AdministradorForm->nome = $resultado[1];
            $AdministradorForm->nivel = $resultado[2];
            $AdministradorForm->email = $resultado[3];
            $AdministradorForm->senha = $resultado[4];

            return $AdministradorForm;
        }
    }

    function Inserir(Administrador $AdministradorForm) {
        $this->conexao = parent::Conexao();

        $hashed_password = password_hash($AdministradorForm->senha, PASSWORD_DEFAULT);

        $this->sql = "insert into $this->tabela (idAdministrador, nome, nivel, email, senha, status) values (null, '$AdministradorForm->nome', $AdministradorForm->nivel, '$AdministradorForm->email', '$hashed_password', 'a');";

        $this->conexao->query($this->sql);
        return $this->conexao->insert_id;
    }

function Atualizar($idAdministrador, $nome, $email, $senhaAtual, $senhaNova) {
        $this->conexao = parent::Conexao();
        
        $this->sql = "SELECT `senha` FROM $this->tabela WHERE `idAdministrador` = '$idAdministrador';";
        
        $busca = $this->conexao->query($this->sql);
        
        $resultado = mysqli_fetch_row($busca);
        
        if ((password_verify($senhaAtual, $resultado[0]))) {
            if ($senhaNova === "") {
                $this->sql = "UPDATE $this->tabela "
                        . "set `nome`= '$nome',"
                        . "`email`= '$email'"
                        . "where `idAdministrador`='$idAdministrador';";
                $this->conexao->query($this->sql);              
                $final = 0;               
            }else{
                $hashed_password = password_hash($senhaNova, PASSWORD_DEFAULT);               
                $this->sql = "UPDATE $this->tabela "
                        . "set `nome`= '$nome',"
                        . " `email`= '$email',"
                        . "`senha`= '$hashed_password'"
                        . "where `idAdministrador`='$idAdministrador';";
                $this->conexao->query($this->sql); 
                $final = 0;
        }
        }else{
            $final = 1;
        }
        return $final;
    }

    function AtualizarSenha($idAdministrador, $senhaVelha, $senhaNova) {
        $this->conexao = parent::Conexao();

        $this->sql = "SELECT `senha` "
                . " FROM $this->tabela WHERE idAdministrador = '$idAdministrador' "
                . "and status = 'ativo'";

        $busca = $this->conexao->query($this->sql);

        $resultado = mysqli_fetch_row($busca);

        if (password_verify($senhaVelha, $resultado[0])) {

            $hashed_password = password_hash($senhaNova, PASSWORD_DEFAULT);

            $this->sql = "UPDATE $this->tabela "
                    . "`senha`='$hashed_password'"
                    . "where `idAdministrador`='$idAdministrador';";
            $this->conexao->query($this->sql);
        }
    }

    function EsqueceuSenha($email, $senha) {
        $this->conexao = parent::Conexao();

        var_dump($email);

        $hashed_password = password_hash($senha, PASSWORD_DEFAULT);

        $this->sql = "update $this->tabela "
                . "set `senha`='$hashed_password'"
                . "where `email`='$email'";

        $this->conexao->query($this->sql);
    }

    function Excluir($idAdministrador) {
        $this->conexao = parent::Conexao();
        $this->sql = "UPDATE $this->tabela "
                . "set `status`='i' "
                . "where `idAdministrador`=$idAdministrador;";
        $this->conexao->query($this->sql);
    }

}
