<?php

require_once 'Banco.php';

class PessoaController extends Banco {

    private $tabela = "tb_pessoa";
    private $conexao;
    private $sql;

    function SelecionarTodos() {//Apenas seleceiona ativos
        // Abre a conxão com o banco de dados
        $this->conexao = parent::Conexao();

        // Montar a consulta(query) do banco de dados de todos os pessoas
        $this->sql = "SELECT `idPessoa`,`rg`,`matricula`,`cpf`,`nomePessoa`,`dataNascimento`,`funcao` "
                . "FROM $this->tabela where status = 'a' order by `matricula`";

        // Executa o comando do banco de dados
        $busca = mysqli_query($this->conexao, $this->sql);

        $listaPessoas = array();

        // Recupera um vetor a partir dos resultados
        while ($dadoPessoa = mysqli_fetch_array($busca)) {
            // Nova instância do pessoa
            $pessoa = new Pessoa();
            // Preencher os atributos com as informações do banco de dados
            $pessoa->idPessoa = $dadoPessoa["idPessoa"];
            $pessoa->rg = $dadoPessoa["rg"];
            $pessoa->matricula = $dadoPessoa["matricula"];
            $pessoa->cpf = $dadoPessoa["cpf"];
            $pessoa->nomePessoa = $dadoPessoa["nomePessoa"];
            $pessoa->dataNascimento = $dadoPessoa["dataNascimento"];
            $pessoa->funcao = $dadoPessoa["funcao"];


            // Cria a lista de pessoas e adiciona mais um item
            $listaPessoas[] = $pessoa;
        }

        return $listaPessoas;
    }

    function SelecionarPorId($idPessoa) {
        $this->conexao = parent::Conexao();

        $this->sql = "SELECT `idPessoa`,`rg`,`matricula`,`cpf`,`nomePessoa`,`dataNascimento`,`funcao` "
                . " FROM $this->tabela WHERE `idPessoa` = '$idPessoa' order by matricula;";

        $busca = $this->conexao->query($this->sql);

        $resultado = mysqli_fetch_row($busca);


        $pessoa = new Pessoa();
        $pessoa->idPessoa = $resultado[0];
        $pessoa->nomePessoa = $resultado[4];
        $pessoa->cpf = $resultado[3];
        $pessoa->rg = $resultado[1];
        $pessoa->matricula = $resultado[2];
        $pessoa->dataNascimento = $resultado[5];
        $pessoa->funcao = $resultado[6];

        return $pessoa;
    }

    function SelecionarPorMatricula($matricula) {

        $this->conexao = parent::Conexao();

        $this->sql = "SELECT `idPessoa`,`rg`,`matricula`,`cpf`,`nomePessoa`,`dataNascimento`,`funcao`"
                . " FROM $this->tabela WHERE `matricula` = '$matricula' order by matricula;";

        $busca = $this->conexao->query($this->sql);

        $resultado = mysqli_fetch_row($busca);

        while ($dadoPessoa = mysqli_fetch_array($busca)) {
            $pessoa = new Pessoa();
            $pessoa->idPessoa = $resultado[0];
            $pessoa->rg = $resultado[1];
            $pessoa->matricula = $resultado[2];
            $pessoa->cpf = $resultado[3];
            $pessoa->nomePessoa = $resultado[4];
            $pessoa->dataNascimento = $resultado[5];
            $pessoa->funcao = $resultado[6];


            $listaPessoas[] = $pessoa;
        }
        return $listaPessoas;
    }

    function SelecionarPorNome($nome) {

        $this->conexao = parent::Conexao();

        $this->sql = "SELECT `idPessoa`,`rg`,`matricula`,`cpf`,`nomePessoa`,`dataNascimento`,`funcao` "
                . " FROM $this->tabela WHERE `nomePessoa` = '$nome';";

        $busca = $this->conexao->query($this->sql);

        $resultado = mysqli_fetch_row($busca);

        while ($dadoPessoa = mysqli_fetch_array($busca)) {
            $pessoa = new Pessoa();
            $pessoa->idPessoa = $resultado[0];
            $pessoa->rg = $resultado[1];
            $pessoa->matricula = $resultado[2];
            $pessoa->cpf = $resultado[3];
            $pessoa->nomePessoa = $resultado[4];
            $pessoa->dataNascimento = $resultado[5];
            $pessoa->funcao = $resultado[6];


            $listaPessoas[] = $pessoa;
        }
        return $listaPessoas;
    }

    function Inserir(Pessoa $pessoa) {
        $this->conexao = parent::Conexao();
        $this->sql = "INSERT INTO  $this->tabela (idPessoa, rg, matricula, cpf, nomePessoa, dataNascimento, funcao, status) "
                . "VALUES(null, "
                . "'$pessoa->rg', "
                . "'$pessoa->matricula', "
                . "'$pessoa->cpf', "
                . "'$pessoa->nomePessoa', "
                . "'$pessoa->dataNascimento', "
                . "'$pessoa->funcao', "
                . "'a'"
                . ");";

        $this->conexao->query($this->sql);
        return $this->conexao->insert_id;
    }

    function Atualizar(Pessoa $pessoa) {
        $this->conexao = parent::Conexao();
        $this->sql = "UPDATE $this->tabela "
                . "SET `rg`='$pessoa->rg',"
                . "`matricula`='$pessoa->matricula',"
                . "`cpf`='$pessoa->cpf',"
                . "`nomePessoa`='$pessoa->nomePessoa',"
                . "`dataNascimento`='$pessoa->dataNascimento',"
                . "`funcao`= '$pessoa->funcao'
                WHERE `idPessoa`= $pessoa->idPessoa;";
        $this->conexao->query($this->sql);
    }

    function Excluir($idPessoa) {
        $this->conexao = parent::Conexao();
        $this->sql = "UPDATE $this->tabela "
                . "set `status`='i' "
                . "where `idPessoa`=$idPessoa;";
        $this->conexao->query($this->sql);
    }

}
